package Clases;

public class Partido {
	
	public String resultado;
	
	public Partido() {
		
	}
	
	public Partido(String resul) {
		this.resultado = resul;
	}
	
	

}
